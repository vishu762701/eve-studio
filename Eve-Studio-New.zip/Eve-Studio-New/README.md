# Eve Studio — Simple edition

## Phone par kaise use karein

1. ZIP extract karke **Eve-Simple.apk** install karein. App ka naam **Eve Simple** hai.
2. Yeh purane Studio ke saath alag install hota hai. Purana Studio uninstall karne ki zaroorat nahi.
3. Upar screen choose karein, preview mein element tap karein, phir Text / Colors / Layout / Effects se edit karein.
4. Light aur Dark dono check karein. **Export → Copy prompt** se implementation instructions lein.
5. **Export → Copy backup** se apni editing ka backup rakhein. Restore ke liye saved text box mein paste karke **Restore from box** dabayein.

Purane Studio ke edits automatically transfer nahi hote. Purane Studio ke More → Show backup ka complete text copy karke naye Studio mein restore kar sakte hain. Original element IDs retained hain. Imported old backgrounds/layout values may override refreshed defaults; keep the old backup until you have reviewed the result.

## What changed

- Simpler screen → element → edit → export flow, clearer labels, contextual selection, and a Done button.
- Original text/color/layout/effect controls, layers, add/duplicate/copy/paste/reorder/delete, reset, lock/hide, undo/redo, comparison, autosave and prompt/backup flows retained.
- All 92 supplied layout resources and 1,948 original element identities retained.
- Source resource colors for light and dark, drawable shapes, vector icons, inherited styles, text sizes, gravity and relative positioning added to previews.
- 31 RecyclerViews linked to the supplied app's item layouts. Preview can show 1, 3 or 5 rows.
- Sample list text stays out of the exported changes.
- Backup validation rejects malformed structure and conflicting element IDs before changing the model.

## Scope and verification

This remains an HTML/WebView design editor. It does **not** run the native Eve application, log into Firebase, load the user's live data, or apply changes directly to the installed app. Dynamic lists use labeled sample data. Remote images, Lottie animations, custom Android drawing and some complex native layouts remain approximations. Pixel-for-pixel parity with the installed Android app is **not verified**.

DOM/JavaScript checks cover 92 layouts in both modes and editing, undo/redo, separate theme colors, spacing/effects, structure operations, backup restore, autosave, compare and export. See `tests/results.json`. These are DOM tests, not screenshot or Android instrumentation tests. The environment prevented Chrome from starting, and no Android device/emulator was available for installation tests.

The packaged APK is aligned and its signatures verified with Android build tools. It reuses the supplied minimal WebView wrapper with a separate package (`com.vishu.evestudi2`) and label (`Eve Simple`). Minimum Android version: 7.0 / API 24; a current Android System WebView is recommended. APK file import/download buttons are hidden in the Android wrapper because it has no native file-picker/download bridge; copy/paste backup remains available.

## Files

- `Eve-Simple.apk`: signed installable package.
- `index.html`: standalone offline editor, also embedded in the APK.
- `source/`: editor generator, renderer, UI styles, original HTML, resource snapshot, APK packaging script and original WebView wrapper.
- `source/signing/`: local development signing key, retained to make future updates to this package possible.
- `tests/`: verification script and results.

## Rebuild

The resource snapshot is from the supplied app ZIP. No production app files or remote repository were modified.

Requirements: Python 3, Java, Android build-tools (tested with 35.0.0). Set `ANDROID_BUILD_TOOLS` to the build-tools directory and run:

```sh
bash source/rebuild.sh
```

Run editor checks with Node and jsdom 26 installed:

```sh
node tests/editor.test.cjs
```

If jsdom is outside Node's module path, set `JSDOM_PATH` to its absolute package directory. The bundled signing key is for this local Studio build; it is not an Eve production signing key.
