#!/usr/bin/env python3
"""Replace the local HTML asset and give this build its own application identity.
Uses the original minimal WebView wrapper; Android build tools sign afterwards.
"""
from pathlib import Path
import zipfile,hashlib,zlib,struct,argparse
p=argparse.ArgumentParser();p.add_argument('base_apk');p.add_argument('output_apk');args=p.parse_args()
root=Path(__file__).resolve().parent.parent
with zipfile.ZipFile(args.base_apk) as src,zipfile.ZipFile(args.output_apk,'w',zipfile.ZIP_DEFLATED) as out:
 for name in src.namelist():
  if name.startswith('META-INF/') or name=='assets/index.html':continue
  data=src.read(name)
  if name=='AndroidManifest.xml':
   old='com.vishu.evestudio'.encode('utf-16le');new='com.vishu.evestudi2'.encode('utf-16le');assert data.count(old)==2
   data=data.replace(old,new).replace('Eve Studio'.encode('utf-16le'),'Eve Simple'.encode('utf-16le')).replace('1.0'.encode('utf-16le'),'2.0'.encode('utf-16le'))
  elif name.endswith('.dex'):
   data=bytearray(data.replace(b'com/vishu/evestudio',b'com/vishu/evestudi2'))
   data[12:32]=hashlib.sha1(data[32:]).digest();data[8:12]=struct.pack('<I',zlib.adler32(data[12:])&0xffffffff)
  out.writestr(name,data,compress_type=zipfile.ZIP_STORED if name=='resources.arsc' else zipfile.ZIP_DEFLATED)
 out.writestr('assets/index.html',(root/'index.html').read_bytes())
print(args.output_apk)
