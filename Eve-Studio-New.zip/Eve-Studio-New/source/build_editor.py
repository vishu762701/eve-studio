#!/usr/bin/env python3
"""Enrich the original Studio model from the supplied Eve resource snapshot."""
from pathlib import Path
import xml.etree.ElementTree as ET
import json,re,html
ROOT=Path(__file__).resolve().parent
RES=ROOT/'app-res'
base=(ROOT/'base.html').read_text()
D=json.loads(base[base.index('var D=')+6:base.index(',M=')])
A='{http://schemas.android.com/apk/res/android}'
P='{http://schemas.android.com/apk/res-auto}'
T='{http://schemas.android.com/tools}'
values={};styles={}
for mode in ['l','d']:
 v={};st={}
 for directory in ['values']+(['values-night'] if mode=='d' else []):
  for p in sorted((RES/directory).glob('*.xml')):
   for e in ET.parse(p).getroot():
    name=e.get('name')
    if e.tag=='style':st[name]=(e.get('parent',name.rsplit('.',1)[0] if '.' in name else ''),{i.get('name'):''.join(i.itertext()) for i in e})
    elif name:v[e.tag+'/'+name]=''.join(e.itertext())
 values[mode]=v;styles[mode]=st

def resolve(s,mode='l',depth=0):
 if not s or depth>16:return s
 if s=='@android:color/transparent' or s=='@null':return 'rgba(0,0,0,0)'
 if s.startswith('@android:color/'):return {'white':'#ffffff','black':'#000000'}.get(s.split('/')[-1])
 if s.startswith('?'):return resolve({'colorPrimary':'@color/eve_primary','colorOnSurface':'@color/eve_text','colorSurface':'@color/eve_surface','colorOnPrimary':'@color/eve_on_primary'}.get(s.split('/')[-1]),mode,depth+1)
 if s.startswith('@'):
  k=s[1:]
  if k in values[mode]:return resolve(values[mode][k],mode,depth+1)
  if k.startswith('color/'):
   for dr in (['color-night','color'] if mode=='d' else ['color']):
    f=RES/dr/(k.split('/')[-1]+'.xml')
    if f.exists():
     es=list(ET.parse(f).getroot());e=next((e for e in es if len(e.attrib)==1),es[-1] if es else None)
     return resolve(e.get(A+'color'),mode,depth+1) if e is not None else None
  return None
 if re.fullmatch(r'#[0-9a-fA-F]{8}',s):
  return 'rgba(%d,%d,%d,%.4f)'%(int(s[3:5],16),int(s[5:7],16),int(s[7:9],16),int(s[1:3],16)/255)
 return s

def num(s,mode='l'):
 s=resolve(s,mode)
 if not s:return None
 try:return float(re.sub(r'(dp|sp|px)$','',s))
 except:return None

def style(name,mode='l',depth=0):
 if not name or depth>15:return {}
 name=name.replace('@style/','');parent,attrs=styles[mode].get(name,('',{}))
 return dict(style(parent,mode,depth+1),**attrs)

def drawable(ref,mode):
 if not ref:return None
 name=ref.split('/')[-1]
 for dr in (['drawable-night','drawable'] if mode=='d' else ['drawable']):
  f=RES/dr/(name+'.xml')
  if f.exists():return ET.parse(f).getroot()
 return None

def shape(ref,mode):
 e=drawable(ref,mode)
 if e is None:return {}
 if e.tag in ['selector','ripple']:
  items=[x for x in e if x.tag=='item']
  if items:
   it=next((x for x in items if not any('state_' in k for k in x.attrib)),items[-1])
   if it.get(A+'drawable'):return shape(it.get(A+'drawable'),mode)
   e=next(iter(it),e)
 if e.tag=='layer-list':
  e=next((x for x in e.iter('shape')),e)
 if e.tag!='shape':return {}
 out={}
 for c in e:
  a={k.split('}')[-1]:v for k,v in c.attrib.items()}
  if c.tag=='solid':out['color']=resolve(a.get('color'),mode)
  elif c.tag=='corners':
   r=num(a.get('radius'),mode) or 0
   out['radii']=[num(a.get(k),mode) if k in a else r for k in ['topLeftRadius','topRightRadius','bottomRightRadius','bottomLeftRadius']]
  elif c.tag=='stroke':out.update(stroke=resolve(a.get('color'),mode),strokeWidth=num(a.get('width'),mode))
  elif c.tag=='gradient':
   colors=[resolve(a[k],mode) for k in ['startColor','centerColor','endColor'] if k in a]
   if all(colors):out['gradient']='linear-gradient(%sdeg,%s)'%(90-(num(a.get('angle'),mode) or 0),','.join(colors))
 if e.get(A+'shape')=='oval':out['radii']=[999]*4
 return out

def svg(ref,mode,tinted=False):
 e=drawable(ref,mode)
 if e is None or e.tag!='vector':return None
 def esc(s):return html.escape(str(s),quote=True)
 def children(e):
  out=[]
  for c in e:
   a={k.split('}')[-1]:v for k,v in c.attrib.items()}
   if c.tag=='group':
    tx=a.get('translateX','0');ty=a.get('translateY','0');px=a.get('pivotX','0');py=a.get('pivotY','0')
    out.append('<g transform="translate(%s %s) translate(%s %s) rotate(%s) scale(%s %s) translate(%s %s)">%s</g>'%(tx,ty,px,py,a.get('rotation','0'),a.get('scaleX','1'),a.get('scaleY','1'),-float(px),-float(py),children(c)))
   elif c.tag=='path':
    ats={'d':a.get('pathData',''),'fill':('currentColor' if tinted else resolve(a.get('fillColor'),mode)) or 'none'}
    if 'strokeColor' in a:ats['stroke']='currentColor' if tinted else resolve(a['strokeColor'],mode) or 'currentColor'
    for k,j in [('strokeWidth','stroke-width'),('strokeLineCap','stroke-linecap'),('strokeLineJoin','stroke-linejoin'),('fillAlpha','fill-opacity'),('strokeAlpha','stroke-opacity')]:
     if k in a:ats[j]=a[k]
    if a.get('fillType')=='evenOdd':ats['fill-rule']='evenodd'
    out.append('<path '+' '.join(k+'="'+esc(v)+'"' for k,v in ats.items())+'/>')
  return ''.join(out)
 return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %s %s" width="100%%" height="100%%" aria-hidden="true">%s</svg>'%(e.get(A+'viewportWidth','24'),e.get(A+'viewportHeight','24'),children(e))

# These mappings follow the supplied Activity and Adapter binding classes.
links={
'activity_main':{'rvExams':'item_exam'},'activity_exam_tests':{'rvTests':'item_exam_test'},
'activity_admin':{'rvQuestions':'item_manage_question','rvAdmins':'item_admin_email'},
'activity_manage_premium':{'rvTransactions':'item_admin_transaction','rvPremiumUsers':'item_admin_premium_user'},
'activity_mistakes':{'rvMistakes':'item_mistake'},'activity_test':{'rvQuestionPalette':'item_palette_circle'},
'activity_result':{'rvResultPalette':'item_palette_circle','rvAnswers':'item_answer'},
'activity_manage_exams':{'rvGeneratedTestsForExam':'item_generated_test'},
'activity_admin_analytics':{'rvExams':'item_analytics_exam','rvQuestions':'item_analytics_question'},
'activity_manage_existing_exams':{'rvExams':'item_existing_exam_admin'},
'activity_generated_tests':{'rvGeneratedTests':'item_generated_test'},
'activity_performance':{'rvTopics':'item_topic_stat'},'activity_history':{'rvHistory':'item_history'},
'dialog_post_replies':{'rvReplies':'item_post_reply'},'activity_flagged_questions':{'rvFlaggedQuestions':'item_flagged_question'},
'activity_notifications':{'rvNotifications':'item_notification'},'activity_manage_polls':{'rvPolls':'item_poll_admin'},
'activity_bookmarks':{'rvBookmarks':'item_bookmark_card'},'activity_send_notification':{'rvSentBroadcasts':'item_sent_broadcast'},
'activity_feedback_messages':{'rvFeedbackMessages':'item_feedback_message'},'activity_activity_log':{'rvAuditLogs':'item_audit_log'},
'activity_manage_users':{'rvUsers':'item_user_admin'},'activity_leaderboard':{'rvLeaderboard':'item_leaderboard'},
'activity_edit_exam':{'rvQuestions':'item_manage_question'},'dialog_manage_banners':{'rvAdminBanners':'item_admin_banner'}}

sizes={'DisplayLarge':57,'DisplayMedium':45,'DisplaySmall':36,'HeadlineLarge':32,'HeadlineMedium':28,'HeadlineSmall':24,'TitleLarge':22,'TitleMedium':16,'TitleSmall':14,'BodyLarge':16,'BodyMedium':14,'BodySmall':12,'LabelLarge':14,'LabelMedium':12,'LabelSmall':11}
count=0

def enrich(n,e,layout,path='0'):
 global count
 count+=1
 attrs={('android:' if k.startswith(A) else '')+k.split('}')[-1]:v for k,v in e.attrib.items()}
 defaults='Widget.Eve.Button' if n['t']=='MaterialButton' else 'Widget.Eve.Card' if n['t']=='MaterialCardView' else None
 a={**style(defaults),**style(attrs.get('style')),**attrs}
 n['xp']=path
 for key,out in [('android:layout_gravity','lg'),('android:contentDescription','desc'),('android:layout_toEndOf','after'),('android:layout_toRightOf','after'),('android:layout_toStartOf','before'),('android:layout_below','below'),('android:layout_alignParentEnd','end'),('android:layout_alignParentBottom','bottom'),('android:layout_centerVertical','centerV'),('android:layout_centerHorizontal','centerH'),('android:layout_centerInParent','centerAll')]:
  if key in a:n[out]=a[key].split('/')[-1]
 for key,out in [('android:minHeight','minH'),('android:minWidth','minW'),('android:maxLines','maxLines'),('android:letterSpacing','letter'),('android:translationY','translateY')]:
  v=num(a.get(key))
  if v is not None:n[out]=v
 for key,out in [('android:textSize','ts'),('cornerRadius','r'),('cardCornerRadius','r')]:
  v=num(a.get(key))
  if v is not None:n[out]=v
 if 'ts' not in n:
  st=a.get('style','').split('.')[-1]
  if st in sizes:n['ts']=sizes[st]
 if a.get('android:textStyle')=='bold':n['bd']=1
 if 'medium' in a.get('android:fontFamily',''):n['fontWeight']=500
 if a.get('android:visibility')=='invisible':n['invisible']=1
 if a.get('android:layout_gravity') in ['start','left'] and layout=='activity_main' and n.get('id')=='navDrawerPanel':n['drawer']=1
 for mode,suf in [('l','L'),('d','D')]:
  if n.get('id')=='chipGroupCategory':
   for token,field in [('eve_chip_selected_bg','chipSelected'),('eve_surface_variant','chipDefault'),('eve_chip_selected_text','chipTextSelected'),('eve_text','chipText')]:n[field+suf]=resolve('@color/'+token,mode)
  am={**style(defaults,mode),**style(attrs.get('style'),mode),**attrs}
  bg=am.get('cardBackgroundColor') or am.get('backgroundTint') or am.get('android:backgroundTint') or am.get('android:background')
  sh=shape(bg,mode)
  bgc=sh.get('color') or resolve(bg,mode)
  if bgc and (bgc.startswith('#') or bgc.startswith('rgb')):n['bg'+suf]=bgc
  if sh:n['shape'+suf]=sh
  tc=resolve(am.get('android:textColor'),mode)
  if tc and (tc.startswith('#') or tc.startswith('rgb')):n['text'+suf]=tc
  tint=resolve(am.get('tint') or am.get('android:tint') or am.get('iconTint'),mode)
  if tint:n['tint'+suf]=tint
  src=am.get('android:src') or am.get('srcCompat') or am.get('icon')
  if src:
   icon=svg(src,mode,bool(tint))
   if icon:n['svg'+suf]=icon
  if am.get('strokeColor'):
   n['stroke'+suf]=resolve(am.get('strokeColor'),mode);n['strokeW']=num(am.get('strokeWidth'),mode) or 0
 if n.get('id') in links.get(layout,{}):n['li']=links[layout][n['id']]
 if e.get(T+'listitem'):n['li']=e.get(T+'listitem').split('/')[-1]
 if n['t']=='LottieAnimationView':
  n['animation']=attrs.get('lottie_rawRes','').split('/')[-1]
  fallback={'btnNotification':'@drawable/ic_notifications','lottieFloatingAirplane':'@drawable/ic_send'}.get(n.get('id'))
  if fallback:
   for m,s in [('l','L'),('d','D')]:
    icon=svg(fallback,m,False)
    if icon:n['svg'+s]=icon
 children=[x for x in e if isinstance(x.tag,str)]
 if len(children)!=len(n.get('ch',[])):
  if children:raise ValueError('Tree mismatch '+layout+' '+path)
 for i,(c,x) in enumerate(zip(n.get('ch',[]),children)):enrich(c,x,layout,path+'/'+str(i))

for name,n in D.items():enrich(n,ET.parse(RES/'layout'/(name+'.xml')).getroot(),name)
# Preserve old node IDs, so old backups can be upgraded without losing edits.
prefix=base[:base.index('var D=')+6];suffix=base[base.index(',M='):]
base=prefix+json.dumps(D,separators=(',',':'),ensure_ascii=False).replace('</',r'<\/')+suffix
base=base.replace('draw();pn();ex();\n</script>','draw();pn();ex();\n</script>')
base=base.replace('id="gd" checked','id="gd"')
base=base.replace('SD=D;D=OR;draw()', 'SD=D;D=OR;ri();draw()').replace('D=SD;SD=null;draw()', 'D=SD;SD=null;ri();draw()')
base=base.replace('if(n.li&&D[n.li]&&d<8){for(var i=0;i<2;i++){','if(n.li&&D[n.li]&&d<24){for(var i=0;i<(window.previewRowCount||3);i++){')
base=base.replace('var hid=n.vis||n.hd;if(hid&&!gh)return null;', 'var hid=n.vis||n.hd||n.drawer;if(hid&&!gh)return null;')
base=base.replace('else if(/RecyclerView/.test(t)&&!ch.length){e.style.minHeight="40px";e.style.outline="1px dashed rgba(128,128,128,.6)";e.textContent="List"}', 'else if(/RecyclerView/.test(t)&&!ch.length){e.style.minHeight="40px";e.textContent="No preview rows"}')
base=base.replace('return e}\nvar BK=', 'return enhanceNode(e,n,m,pb,po,d)}\nvar BK=')
# Functions are declared before the legacy initialization executes.
base=base.replace('function rn(n,m,pb,po,d){',(ROOT/'renderer.js').read_text()+'\nfunction rn(n,m,pb,po,d){')
base=base.replace('</style></head>','\n'+(ROOT/'studio.css').read_text()+'\n</style></head>')
base=base.replace('<title>Eve full studio</title>','<title>Eve Studio — Simple</title>')
base=base.replace('</body></html>','<script>\n'+(ROOT/'studio.js').read_text()+'\n</script></body></html>')
(ROOT.parent/'index.html').write_text(base)
print(json.dumps({'layouts':len(D),'nodes':count,'linked_lists':sum(1 for n in json.dumps(D).split('"li":'))-1,'bytes':len(base.encode())}))
