(function(){
 'use strict';
 var top=$('#top'),brand=document.createElement('div');brand.className='brand';brand.innerHTML='<div><strong>Eve Studio</strong><small>Choose · Tap · Edit</small></div><button id="studioHelp">Help</button>';top.prepend(brand);
 $('#fq').placeholder='Find a screen…';$('#ly').setAttribute('aria-label','Choose a screen');$('#fq').setAttribute('aria-label','Search screens');$('#cmp').textContent='Hold to compare';
 var intro=document.createElement('div');intro.className='intro';intro.innerHTML='<div class="intro-text">Tap an element to edit its design.<br><span id="sample-note">App layouts + sample data. Live content and animations may differ.</span></div><button id="studioSettings">Settings</button>';top.after(intro);
 var actions=document.createElement('div');actions.className='selection-actions';actions.innerHTML='<button id="parentQuick">Parent</button><button id="listQuick" hidden>List template</button><button id="closeQuick" class="close-editor">Done</button>';$('#dr').prepend(actions);
 $('#parentQuick').onclick=function(){$('#pr').click()};$('#closeQuick').onclick=function(){opn(false)};
 var help=document.createElement('div');help.className='help-panel';help.hidden=true;help.innerHTML='<p><b>1. Choose a screen</b> using the menu at the top.</p><p><b>2. Tap an element</b> in the preview. Use Parent for a whole card, or Layers to find small/hidden elements.</p><p><b>3. Edit</b> text, color, layout or effects. Check Light and Dark.</p><p><b>4. Export</b> the implementation prompt. Keep a backup to restore your work later.</p><p>Changes are saved on this device. List rows share one template. Sample text is preview-only. This Studio does not change the installed Eve app.</p>';intro.after(help);
 $('#studioHelp').onclick=function(){help.hidden=!help.hidden;this.textContent=help.hidden?'Help':'Close help'};
 $('#studioSettings').onclick=function(){opn(true);showTab('mo')};
 var advanced=document.createElement('div');advanced.className='advanced-row';advanced.innerHTML='<button id="moveUp">Move up</button><button id="moveDown">Move down</button>';$('#sc_ad').appendChild(advanced);$('#moveUp').onclick=function(){$('#up').click()};$('#moveDown').onclick=function(){$('#dn').click()};
 document.querySelector('[data-s="ad"]').textContent='Arrange';document.querySelector('[data-s="mo"]').textContent='Save & tools';document.querySelector('[data-s="co"]').textContent='Colors';
 $('#sc_mo').insertAdjacentHTML('afterbegin','<div class="help-panel">Edits auto-save on this device. Export a prompt to apply them to your app, or keep a backup before reinstalling.</div><div class="export-actions"><button id="copyPrompt">Copy prompt</button><button id="copyBackup">Copy backup</button><button id="downloadBackup">Download backup</button><button id="importBackup">Import backup</button></div><input id="backupFile" type="file" accept=".json,.txt" hidden><div class="k"><label for="sampleRows">Preview rows</label><select id="sampleRows"><option value="1">1 row</option><option value="3" selected>3 rows</option><option value="5">5 rows</option></select><label><input id="sampleData" type="checkbox" checked> Sample text</label></div>');
 $('#copyPrompt').onclick=function(){var text=$('#ex').value;if(!text){$('#sst').textContent='No changes to export yet';return}$('#bx').value=text;cpy(text,this);};
 $('#copyBackup').onclick=function(){$('#bx').value=bkp();cpy(bkp(),this)};
 $('#downloadBackup').onclick=function(){var content=bkp();$('#bx').value=content;var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type:'text/plain'}));a.download='eve-studio-backup.txt';a.click();setTimeout(function(){URL.revokeObjectURL(a.href)},30000);$('#sst').textContent='If no download appears, use Copy backup.';};
 if(/Android/i.test(navigator.userAgent)&&location.protocol==='file:'){$('#downloadBackup').hidden=true;$('#importBackup').hidden=true;}
 $('#importBackup').onclick=function(){$('#backupFile').click();$('#sst').textContent='Or paste a backup into the box and tap Restore from box.';};
 $('#backupFile').onchange=function(){var f=this.files[0];if(!f)return;var reader=new FileReader();reader.onload=function(){$('#bx').value=reader.result;$('#fr').click()};reader.readAsText(f);this.value=''};
 $('#sampleRows').onchange=function(){window.previewRowCount=+this.value;draw()};$('#sampleData').onchange=function(){window.previewSamples=this.checked;draw()};
 // Keep all original handlers. Wrap the renderer only for layout measurement and UI status.
 var originalDraw=draw,originalPn=pn,originalEx=ex,originalOpen=opn,originalSave=sv;
 draw=function(){originalDraw();measureRelative();requestAnimationFrame(measureRelative);var theme=mode==='d'?'dark':'light';document.documentElement.dataset.theme=theme;updateStatus()};
 pn=function(){originalPn();var o=IDX[sel];if(o){$('#nm').textContent=(o.n.id||o.n.tx||o.n.t)+' · '+fn(o.l);$('#listQuick').hidden=!o.n.li;$('#parentQuick').disabled=!o.p;}else{$('#nm').textContent='Tap an element in the preview';$('#listQuick').hidden=true;$('#parentQuick').disabled=true;}updateStatus()};
 ex=function(){originalEx();$('#cp').textContent='Export'+(Object.keys(CH).length?' ('+Object.keys(CH).length+')':'');updateStatus()};
 opn=function(v){originalOpen(v);$('#ed').textContent=v?'Done':'Edit';$('#ed').classList.toggle('active',!!v)};
 sv=function(){originalSave();$('#sst').textContent=$('#sst').textContent==='Auto-saved'?'Saved on this device':$('#sst').textContent};
 $('#cp').onclick=function(){opn(true);showTab('mo');$('#bx').value=$('#ex').value||bkp()};
 $('#ed').onclick=function(){opn(!$('#dr').classList.contains('open'))};
 $('#listQuick').onclick=function(){var o=IDX[sel];if(o?.n.li){cur=o.n.li;sel=D[cur].u;$('#fq').value='';refSel();draw();pn();showTab('ly');}};
 function updateStatus(){
  $('#un').disabled=!U.length;$('#re').disabled=!RD.length;
  var o=IDX[sel];$('#ed').disabled=!o&&curTab!=='mo'&&curTab!=='ly';
  document.querySelectorAll('#sc_tx input,#sc_tx textarea,#sc_tx select,#sc_co input,#sc_co button,#sc_sz input,#sc_sz select,#sc_sz button,#sc_st input,#sc_ad button').forEach(function(e){e.disabled=!o});
 }
 // Auto-open the useful property tab; structural tools remain available.
 var previewClick=$('#pv').onclick;$('#pv').onclick=function(event){previewClick(event);var o=IDX[sel];if(o){showTab((o.n.tx!==undefined||o.n.t==='TextView'||/EditText/.test(o.n.t))?'tx':'co');pn();}};
 // Validate complete backups before mutating anything; restores can be undone per screen.
 $('#fr').onclick=function(){try{
  var raw=$('#bx').value.trim().replace(/^EVE_STUDIO_BACKUP\s*/,''),data=JSON.parse(raw);
  if(!data||Array.isArray(data)||typeof data!=='object')throw Error('Invalid backup');
  var keys=Object.keys(data);if(!keys.length){$('#sst').textContent='Backup contains no edits';return;}
  var used=new Set(),valid=0;
  function check(n,depth){if(!n||typeof n!=='object'||!Number.isSafeInteger(n.u)||typeof n.t!=='string'||depth>50||used.has(n.u))throw Error('Invalid element');used.add(n.u);if(n.ch!=null){if(!Array.isArray(n.ch))throw Error('Invalid children');n.ch.forEach(function(c){check(c,depth+1)})}}
  keys.forEach(function(k){if(!OR[k])throw Error('Unknown screen');check(data[k],0);valid++});
  // Reject collisions with nodes outside the restored set.
  Object.keys(IDX).forEach(function(u){if(!keys.includes(IDX[u].l)&&used.has(+u))throw Error('Conflicting element IDs')});
  keys.forEach(function(k){snap(k,Math.random());var originals={};walk(OR[k],function(n){originals[n.u]=n});walk(data[k],function(n){var orig=originals[n.u];if(orig)Object.keys(orig).forEach(function(field){if(!(field in n)&&!['ch','hd','lk','gl','sh','tx','bgL','bgD','r','p','m','w','h'].includes(field))n[field]=JSON.parse(JSON.stringify(orig[field]))});if(n.u>nu)nu=n.u});D[k]=data[k];dirty[k]=1});
  ri();sv();sel=0;draw();pn();ex();$('#sst').textContent='Restored '+valid+' edited screen'+(valid===1?'':'s');
 }catch(error){$('#sst').textContent='Invalid backup. No edits were changed.'}};
 // Prevent comparing original while an edit control is active from changing the baseline.
 document.addEventListener('pointerup',cOff);window.addEventListener('blur',cOff);
 ['#gd','#bk2','#zm'].forEach(function(id){$(id).onchange=function(){draw()}});
 $('#fq').oninput=function(){var q=this.value.toLowerCase().trim();$('#ly').innerHTML=opts(q);if(!$('#ly').options.length){$('#sst').textContent='No screens match your search';return}if(!Array.from($('#ly').options).some(function(x){return x.value===cur})){cur=$('#ly').options[0].value;sel=0;}$('#ly').value=cur;draw();pn()};
 document.querySelectorAll('input,select,textarea').forEach(function(el){if(!el.getAttribute('aria-label')&&!el.labels?.length){el.setAttribute('aria-label',el.placeholder||el.id)}});
 window.addEventListener('resize',measureRelative);draw();pn();ex();opn(false);
})();
