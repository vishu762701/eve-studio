/* Resource-aware preview. Sample values never modify or enter the exported model. */
function sampleText(n){
 if(window.previewSamples===false)return '';
 var v={tvExamName:'RPSC 2nd Grade',tvExamTime:'120 min · Teaching',tvTestName:'English — Mock Test',tvTitle:'Sample title',tvQuestion:'Choose the correct answer.',tvName:'Student',tvUserName:'Student',tvRank:'12',tvScore:'72 / 100',tvScorePercentage:'72%',tvStats:'100 questions · 120 minutes',tvCorrectCount:'72',tvWrongCount:'18',tvUnattemptedCount:'10',tvAccuracy:'80%',tvPercentile:'88%',tvTopicName:'English grammar',tvMessage:'Your updates appear here',tvNotificationTitle:'New mock test available',tvNotificationBody:'Practice at your own pace.',tvTime:'10 min ago',tvSubject:'English',tvCategory:'Teaching',tvDate:'08 Oct 2026',tvExamTitle:'RPSC 2nd Grade',tvQuestionNumber:'1',tvOptionText:'Sample answer',tvPaletteNumber:'1',tvStreakSummary:'3 day streak'};
 return v[n.id]||'';
}
function enhanceNode(e,n,m,pb,po,d){
 var suf=m==='l'?'L':'D',s=e.style,t=n.t,isImage=/Image|Lottie|FlameAnimation|Telegram3DStar/.test(t),isFrame=/^(FrameLayout|MaterialCardView|CardView|DrawerLayout)$/.test(t);
 e.dataset.type=t;if(n.id)e.dataset.view=n.id;
 s.lineHeight='1.25';s.flexShrink='0';
 if(n.w==='w' && po!=='h')s.alignSelf='flex-start';
 if(n.h==='z'&&n.wt){s.flex=n.wt+' 1 0px';s.minHeight='0';}
 if(n.h==='m'&&po==='v'){s.flex='1 1 auto';s.minHeight='0';}
 if(n.minH!=null)s.minHeight=n.minH+'px';if(n.minW!=null)s.minWidth=n.minW+'px';
 if(n.textL&&!n.tc){var original=null;var info=IDX[n.u];if(info)walk(OR[info.l],function(x){if(x.u===n.u)original=x});if(!original||n['bg'+suf]===original['bg'+suf])s.color=n['text'+suf];}
 if(n.fontWeight&&!n.bd)s.fontWeight=n.fontWeight;
 if(n.letter!=null)s.letterSpacing=n.letter+'em';
 if(n.translateY)s.transform='translateY('+n.translateY+'px)';
 if(n.maxLines){s.overflow='hidden';if(n.maxLines===1){s.whiteSpace='nowrap';s.textOverflow='ellipsis';}}
 var sh=n['shape'+suf];
 if(sh){if(sh.radii&&n.r==null)s.borderRadius=sh.radii.map(function(v){return v+'px'}).join(' ');if(sh.gradient)s.backgroundImage=sh.gradient;
 if(sh.stroke&&!n.bk)s.border=(sh.strokeWidth||1)+'px solid '+sh.stroke;}
 if(n['stroke'+suf]&&!n.bk&&n.strokeW)s.border=n.strokeW+'px solid '+n['stroke'+suf];
 if(isImage){
  // Original renderer used grey rectangles for every icon, including transparent icons.
  if(!n.bgL&&!n.bgD)s.background='transparent';
  s.display='flex';s.alignItems='center';s.justifyContent='center';
  if(n['tint'+suf])s.color=n['tint'+suf];
  var icon=n['svg'+suf];
  if(icon){e.innerHTML=icon;}
  else if(t==='LottieAnimationView'&&n.id==='btnNotification')e.innerHTML='<svg viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M5 17h14l-2-3V9a5 5 0 0 0-10 0v5zM10 20h4"/></svg>';
  else if(t==='FlameAnimationView')e.textContent='♨';
  else if(t==='LottieAnimationView'){s.fontSize='11px';e.textContent=n.desc||'Animation';e.title='Animation preview placeholder';}
  else if(!n.src){s.border='1px dashed rgba(128,128,128,.4)';e.title=n.desc||'Dynamic image';}
 }
 if(!n.tx&&!n.ch&&!isImage){var text=sampleText(n);if(text){e.textContent=text;e.dataset.sample='true';}}
 if(n['svg'+suf]&&!isImage){var ico=document.createElement('span');ico.innerHTML=n['svg'+suf];ico.style.cssText='display:inline-flex;width:18px;height:18px;flex:none;margin-right:8px';e.prepend(ico);}
 if(isFrame&&n.ch){s.display='grid';s.gridTemplateColumns='minmax(0,1fr)';s.gridTemplateRows='minmax(0,1fr)';s.alignItems='stretch';
  Array.from(e.children).forEach(function(c){c.style.gridArea='1 / 1';var cn=IDX[+c.dataset.u]?.n;if(!cn)return;
   var g=cn.lg||'';c.style.justifySelf=/end|right/.test(g)?'end':/center/.test(g)?'center':'start';c.style.alignSelf=/bottom/.test(g)?'end':/center/.test(g)?'center':'start';
   if(cn.h==='m')c.style.alignSelf='stretch';if(cn.w==='m'){c.style.justifySelf='stretch';c.style.width='auto';}
  });
 }
 if(t==='RelativeLayout'){s.position='relative';s.display='block';e.dataset.relative='1';}
 if(/ScrollView/.test(t)){s.overflowY=t==='HorizontalScrollView'?'hidden':'auto';s.overflowX=t==='HorizontalScrollView'?'auto':'hidden';s.minHeight='0';if(t==='HorizontalScrollView')s.flexShrink='0';}
 if(t==='RecyclerView'&&n.li){s.display='flex';s.flexDirection='column';s.overflowY='auto';s.minHeight='60px';
  if(/Palette/.test(n.id||'')){s.display='grid';s.gridTemplateColumns='repeat(5,minmax(0,1fr))';s.gap='8px';}
 }
 if(t==='ChipGroup'&&n.id==='chipGroupCategory'&&!(n.ch||[]).length&&window.previewSamples!==false){
  s.display='flex';s.gap='8px';['All','Teaching','SSC','Railway'].forEach(function(txt,i){var c=document.createElement('span');c.textContent=txt;c.style.cssText='padding:10px 16px;border-radius:99px;white-space:nowrap;font-size:13px;background:'+(n[(i===0?'chipSelected':'chipDefault')+suf]||'transparent')+';color:'+(n[(i===0?'chipTextSelected':'chipText')+suf]||'inherit');e.appendChild(c)});
 }
 if(t==='TabLayout'){
  s.display='flex';s.flexDirection='row';s.gap='4px';s.padding='4px';s.borderRadius='99px';s.minHeight='44px';
  var labels=n.id==='tabLayoutResult'?['Overview','Review','Analysis']:n.id==='tabLayoutTests'?['All','Attempted']:[];
  if(labels.length&&!e.children.length)labels.forEach(function(txt,i){var c=document.createElement('span');c.textContent=txt;c.style.cssText='flex:1;text-align:center;padding:10px 5px;border-radius:99px;font-size:13px;'+(i===0?'background:'+(m==='l'?'#fff':'#3A3A3C'):'');e.appendChild(c)});
 }
 if(t==='TextView'||t==='EditText'){s.whiteSpace=n.maxLines===1?'nowrap':'pre-wrap';}
 return e;
}
function measureRelative(){
 document.querySelectorAll('[data-relative]').forEach(function(p){
  var children=Array.from(p.children).filter(function(e){return e.dataset.u});
  children.forEach(function(e){e.style.position='absolute';e.style.top='0';e.style.left='0';});
  var padding=parseFloat(getComputedStyle(p).paddingLeft)||0,top=parseFloat(getComputedStyle(p).paddingTop)||0;
  for(var pass=0;pass<3;pass++)children.forEach(function(e){var n=IDX[+e.dataset.u]?.n;if(!n)return;var margin=n.m||[0,0,0,0],left=padding+margin[3],right=padding+margin[1],y=top+margin[0];
   var anchor=function(id){return children.find(function(x){return x.dataset.view===id})};
   var a=anchor(n.after);if(a)left=a.offsetLeft+a.offsetWidth+margin[3];
   var b=anchor(n.before);if(b)right=p.clientWidth-b.offsetLeft+margin[1];
   var below=anchor(n.below);if(below)y=below.offsetTop+below.offsetHeight+margin[0];
   e.style.margin='0';e.style.top=y+'px';
   if(n.end==='true'){e.style.left='auto';e.style.right=right+'px'}else {e.style.left=left+'px';e.style.right='auto';}
   if(n.w==='m'||n.after&&n.before)e.style.width=Math.max(0,p.clientWidth-left-right)+'px';
  });
  var height=Math.max(0,...children.map(function(e){return e.offsetTop+e.offsetHeight}))+top;
  p.style.minHeight=height+'px';
  children.forEach(function(e){var n=IDX[+e.dataset.u]?.n;if(n?.centerV==='true'||n?.centerAll==='true')e.style.top=Math.max(top,(height-e.offsetHeight)/2)+'px';if(n?.centerH==='true'||n?.centerAll==='true')e.style.left=Math.max(padding,(p.clientWidth-e.offsetWidth)/2)+'px';});
 });
}
