#!/usr/bin/env bash
set -euo pipefail
studio_root="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_BUILD_TOOLS:?Set ANDROID_BUILD_TOOLS to your installed Android build-tools directory}"
studio_work="$(mktemp -d)"
trap 'rm -rf "$studio_work"' EXIT
python3 "$studio_root/source/build_editor.py"
python3 "$studio_root/source/package_apk.py" "$studio_root/source/wrapper/original-webview.apk" "$studio_work/unsigned.apk"
"$ANDROID_BUILD_TOOLS/zipalign" -f 4 "$studio_work/unsigned.apk" "$studio_work/aligned.apk"
java -jar "$ANDROID_BUILD_TOOLS/lib/apksigner.jar" sign --ks "$studio_root/source/signing/eve-simple.jks" --ks-pass pass:eve-studio-local --key-pass pass:eve-studio-local --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true --v4-signing-enabled false --out "$studio_root/Eve-Simple.apk" "$studio_work/aligned.apk"
java -jar "$ANDROID_BUILD_TOOLS/lib/apksigner.jar" verify --verbose "$studio_root/Eve-Simple.apk"
